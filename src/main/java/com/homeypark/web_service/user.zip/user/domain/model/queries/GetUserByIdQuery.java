package com.homeypark.web_service.user.domain.model.queries;

public record GetUserByIdQuery (Long userId) {}