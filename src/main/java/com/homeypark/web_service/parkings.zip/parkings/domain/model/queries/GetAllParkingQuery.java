package com.homeypark.web_service.parkings.domain.model.queries;

public record GetAllParkingQuery() {}
