package com.homeypark.web_service.parkings.interfaces.rest.resources;

public record UpdateScheduleResource(String startTime,
                                     String endTime) {
}
