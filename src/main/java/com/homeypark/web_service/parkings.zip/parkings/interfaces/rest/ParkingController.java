package com.homeypark.web_service.parkings.interfaces.rest;

import com.homeypark.web_service.parkings.application.internal.commandServices.ParkingCommandService;
import com.homeypark.web_service.parkings.application.internal.queryServices.ParkingQueryService;
import com.homeypark.web_service.parkings.domain.model.commands.DeleteParkingCommand;
import com.homeypark.web_service.parkings.domain.model.entities.Parking;
import com.homeypark.web_service.parkings.domain.model.queries.GetAllParkingQuery;
import com.homeypark.web_service.parkings.interfaces.rest.resources.CreateParkingResource;
import com.homeypark.web_service.parkings.interfaces.rest.resources.UpdateParkingResource;
import com.homeypark.web_service.parkings.interfaces.rest.transformers.CreateParkingCommandFromResourceAssembler;
import com.homeypark.web_service.parkings.interfaces.rest.transformers.UpdateParkingCommandFromResourceAssembler;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/parking")
@Tag(name="Parking", description = "Parking Managment Endpoints")
public class ParkingController {
    private final ParkingCommandService parkingCommandService;
    private final ParkingQueryService parkingQueryService;


    public ParkingController(ParkingCommandService parkingCommandService, ParkingQueryService parkingQueryService) {
        this.parkingCommandService = parkingCommandService;
        this.parkingQueryService = parkingQueryService;
    }

    @GetMapping
    public ResponseEntity<List<Parking>> getAllParking() {
        var getAllParkingQuery = new GetAllParkingQuery();
        var parkingList = parkingQueryService.handle(getAllParkingQuery);

        return new ResponseEntity<>(parkingList, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Parking> createUser(@RequestBody CreateParkingResource createParkingResource) {
        var createParkingCommand = CreateParkingCommandFromResourceAssembler.toCommandFromResource(createParkingResource);

        var parking = parkingCommandService.handle(createParkingCommand);

        return parking.map(p -> new ResponseEntity<>(p, HttpStatus.CREATED)).orElse(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Parking> updateParking(@PathVariable Long id, @RequestBody UpdateParkingResource updateParkingResource){

        var updateParkingCommand = UpdateParkingCommandFromResourceAssembler.toCommandFromResource(id, updateParkingResource);

        var updatedParking = parkingCommandService.handle(updateParkingCommand);

        return updatedParking.map(p -> new ResponseEntity<>(p, HttpStatus.OK)).orElse(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteParking(@PathVariable Long id){
        var deleteParkingCommand = new DeleteParkingCommand(id);
        parkingCommandService.handle(deleteParkingCommand);
        return ResponseEntity.ok("Parking with given id succesfully deleted");
    }
}
